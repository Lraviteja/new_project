from django.contrib import admin

# Register your models here.
from .models import *

class QuestionAdmin(admin.ModelAdmin):
    searchfields = ('Question_text','slug')
    list_display = ('slug','tittle','c_on','u_on')

admin.site.register(Categories)
admin.site.register(Question,QuestionAdmin)
admin.site.register(Answer)
admin.site.register(Comment)

