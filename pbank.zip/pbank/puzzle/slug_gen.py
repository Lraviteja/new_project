import random
import string

def random_slug(strlength = 5):

    return " ".join(random.choice(string.digits) for i in range(strlength))
