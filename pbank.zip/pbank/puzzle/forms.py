from django import forms

from puzzle.models import Question

from puzzle.models import Answer


class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        exclude = ("slug", "is_active", "c_on", "u_on", )

class AnswerForm(forms.ModelForm):
    class Meta:
        model = Answer
        exclude = ("c_on", "u_on", )
