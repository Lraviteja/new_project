from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('login/',views.login_user,name='login_url'),
    path('logout/',views.logout_view,name='logout_url'),
    path('login/my-app/',views.dashboard,name='dashboard'),
    path('question/',views.question,name='questions_url'),
    path('answer/',views.answer,name= 'answer_url'),

]