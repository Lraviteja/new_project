from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

# Create your views here.
from django.http import HttpResponse

from puzzle.forms import QuestionForm

from puzzle.forms import AnswerForm


def index(request):
    return render(request, 'index.html', locals())

    # return HttpResponse("Hello, django. you showed me the shit")


def login_user(request):
    if request.method == "POST":
        username = request.POST.get("username", None)
        psw = request.POST.get('psw', None)
        is_auth = authenticate(request, username=username, password=psw)
        if is_auth:
            login(request, is_auth)
            return redirect('my-app/')

        else:
            error = "Invalid username and password ^_^ "

    return render(request, "login.html", locals())


@login_required(login_url="/login/")
def dashboard(request):
    return render(request, "dashboard.html", locals())


def logout_view(request):
    logout(request)
    return render(request, "logout.html", locals())


def question(request):
    if request.method == "POST":
        form = QuestionForm(request.POST)
        if form.is_valid():
            form.save()
            a = "successfully saved !"
    else:
        form = QuestionForm()
    return render(request, "Questions.html", locals())


def answer(request):
    if request.method == "POST":
        form = AnswerForm(request.POST)
        if form.is_valid():
            form.save()
            b = "answer submitted successfully !!!"
    else:
        form = AnswerForm()
    return render(request, "Answer.html", locals())

