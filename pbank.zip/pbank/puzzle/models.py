from django.contrib.auth.models import User
from django.db import models
from puzzle.slug_gen import random_slug



# Create your models here.
class Categories(models.Model):
    categories_text = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    c_on = models.DateTimeField(auto_now_add=True, editable=False)
    u_on = models.DateTimeField(auto_now=True, editable=False)

    def __str__(self):
        return self.categories_text

class Question(models.Model):
    question_text = models.TextField(default=None)
    tittle = models.CharField(max_length=200)
    slug = models.CharField(default=None, max_length= 100 , blank=True, unique=True)
    category_relation = models.ForeignKey(Categories, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    c_on = models.DateTimeField(auto_now_add=True,editable=False)
    u_on = models.DateTimeField(auto_now=True,editable=False)
    print(u_on)

    def __str__(self):
        return self.question_text
    class meta:
        ordering = ("-c_on",)

    def save(self, *args, **kwargs):

        if not self.slug:
            self.slug = random_slug()

        super().save(*args, **kwargs)

class Answer(models.Model):
    answer_text = models.TextField(default=None)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    c_on = models.DateTimeField(auto_now_add=True, editable=False)
    u_on = models.DateTimeField(auto_now=True, editable=False)

    def __str__(self):
        return self.answer_text


class Comment(models.Model):

    comment_text = models.TextField(default=None)
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    c_on = models.DateTimeField(auto_now_add=True, editable=False)
    u_on = models.DateTimeField(auto_now=True, editable=False)

    def __str__(self):
        return self.comment_text

